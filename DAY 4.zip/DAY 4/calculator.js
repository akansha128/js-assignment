console.log("calculator");
let num1 = prompt("Enter a first number");
let num2 = prompt("Enter a second number");
let opt  = prompt("choose your operator");
console.log("First number is",num1 ," and second number is",num2);
let Result;

switch(opt)
{
    case '+':
        Result=+num1 + +num2
        console.log("Addition of two numbers:",Result)
        break;
    case '-':
        Result=+num1 - +num2
        console.log("Substraction of two numbers:",Result)
        break;
    case '*':
         Result=+num1 * +num2
         console.log("Multiplication of two numbers:",Result)
        break;
    case '/':
          Result=+num1 / +num2
          console.log("Division of two numbers:",Result)
         break; 
    case '%':
           Result=+num1 % +num2
          console.log("Remainder:",Result)
    case 'percentage':
           Result =(+num1/+num2)*100
           console.log("percentage is:",Result)
         break;
    case 'sqrt':
           Result = (Math.sqrt(+num1));
           console.log("Square roots of  numbers is",Result)
         break;
    default:
        console.log("Please enter valid operator");

}
 