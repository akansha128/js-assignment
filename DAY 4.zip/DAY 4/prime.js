console.log("print prime numbers from 0 to n ");

    let store =[],i,j,primes =[];
    let num=prompt("Enter a number to which you want to print prime numbers");
    for(i=2;i<=num;++i)
    {
       if(!store[i])
      {
         primes.push(i);
        for(j =i <<1; j<=num; j+=i)
        {
            store[j]=true;

        }
      }
    }
   
  console.log("prime numbers are :",primes);
    
