console.log("shopping");
let shoppingList= ["Lays","maggie","coldDrinks"];
 let shoppingBasket=shoppingList;
 shoppingList.push("chocolates","icecream");
 console.log(shoppingList);