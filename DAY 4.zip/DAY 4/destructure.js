console.log("Destructure of object");
const student={
       name: "helsinki",
       age: 24,
       projects:{
           dicegame:"Two player dicegame using javascript"
       }

}
 
const{name, age ,projects:{dicegame}} = student;
console.log(name,age,dicegame);